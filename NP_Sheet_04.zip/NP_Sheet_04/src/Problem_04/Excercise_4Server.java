/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Problem_04;

import java.awt.BorderLayout;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 *
 * @author Mhmoud
 */
public class Excercise_4Server extends JFrame {

    private JTextArea serverConsole = new JTextArea();
    private RandomAccessFile raf;
    private int count; // Count the access to the server

    public static void main(String[] args) {
        new Excercise_4Server();
    }

    public Excercise_4Server() {

        setLayout(new BorderLayout());
        add(new JScrollPane(serverConsole), BorderLayout.CENTER);
        JButton stopButton = new JButton("Stop");
        add(stopButton,BorderLayout.SOUTH);
        stopButton.addActionListener(e->{
        try
        {
                // Write new count back to the file
                raf.seek(0);
                raf.writeInt(count);
                serverConsole.append("Total No. of Visitors = " + count);
        }
        catch(Exception ex){}
        });
        
        serverConsole.setWrapStyleWord(true);
        serverConsole.setLineWrap(true);

        setTitle("Exercise_1Server");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        try {
            ServerSocket serverSocket = new ServerSocket(8000);
            serverConsole.append("Exercise_1Server started at " + new Date() + '\n');

            //int clientNo = 1;
            raf = new RandomAccessFile("count.dat", "rw");

            // Get the count
            if (raf.length() == 0) {
                count = 0;
            } else {
                count = raf.readInt();
            }
            serverConsole.append("Total No. of Visitors = " + count);
            while (true) {
                Socket connectToClient = serverSocket.accept();
                DataOutputStream outputToClient = new DataOutputStream(connectToClient.getOutputStream());
                serverConsole.append("Starting thread for client " + count + " at " + new Date() + '\n');

                InetAddress clientInetAddress
                        = connectToClient.getInetAddress();
                serverConsole.append("Client " + count + "'s host name is "
                        + clientInetAddress.getHostName() + "\n");
                serverConsole.append("Client " + count + "'s IP Address is "
                        + clientInetAddress.getHostAddress() + "\n");
                HandleAClient thread = new HandleAClient(connectToClient);
                thread.start();
                count++;
                outputToClient.writeInt(count);


            }
        } catch (IOException ex) {
            System.out.println("Error Ocurred!");
        }
    }

    class HandleAClient extends Thread {

        private Socket connectToClient;

        public HandleAClient(Socket socket) {
            connectToClient = socket;
        }

        public void run() {
            try {
                DataInputStream inputFromClient = new DataInputStream(
                        connectToClient.getInputStream());
                DataOutputStream outputToClient = new DataOutputStream(
                        connectToClient.getOutputStream());

                while (true) {

                }
            } catch (IOException e) {
                System.out.println("Error Ocurred!");
            }
        }
    }
}
