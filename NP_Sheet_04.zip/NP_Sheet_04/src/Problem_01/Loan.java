/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Problem_01;

import java.util.StringTokenizer;

/**
 *
 * @author Mhmoud
 */
public class Loan {
  private double annualInterestRate;
  private int numberOfYears;
  private double loanAmount;
  
  public Loan(double annualInterestRate, int numberOfYears,
      double loanAmount) {
    this.annualInterestRate = annualInterestRate;
    this.numberOfYears = numberOfYears;
    this.loanAmount = loanAmount;
  }
  
  public double getMonthlyPayment() {
    double monthlyInterestRate = annualInterestRate / 1200;
    double monthlyPayment = loanAmount * monthlyInterestRate / (1 -
      (Math.pow(1 / (1 + monthlyInterestRate), numberOfYears * 12)));
    return monthlyPayment;    
  }

  public double getTotalPayment() {
    double totalPayment = getMonthlyPayment() * numberOfYears * 12;
    return totalPayment;    
  }
  
  public static void main(String[]args)
  {
  StringTokenizer st=new StringTokenizer("All is well!");
  st.nextToken();
  System.out.println(st.nextToken().trim());
  
  
  }
}
