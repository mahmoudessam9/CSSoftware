/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Problem_01;

/**
 *
 * @author Mhmoud
 */
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Exercise_1Client extends JFrame {

  private JTextField annualRateField = new JTextField();
  private JTextField numYearsField = new JTextField();
  private JTextField loanAmountField = new JTextField();
  private JButton submitButton= new JButton("Submit");

  private JTextArea clientConsole = new JTextArea();

  DataOutputStream outputToServer;
  DataInputStream inputFromServer;

  public static void main(String[] args) {
    new Exercise_1Client();
  }

  public Exercise_1Client() {

    JPanel labelsPanel = new JPanel();
    labelsPanel.setLayout(new GridLayout(3, 1));
    labelsPanel.add(new JLabel("Annual Interest Rate"));
    labelsPanel.add(new JLabel("Number Of Years"));
    labelsPanel.add(new JLabel("Loan Amount"));

    Panel fieldsPanel = new Panel();
    fieldsPanel.setLayout(new GridLayout(3, 1));
    fieldsPanel.add(annualRateField);
    fieldsPanel.add(numYearsField);
    fieldsPanel.add(loanAmountField);

    JPanel mainPanel = new JPanel();
    mainPanel.setLayout(new BorderLayout());
    mainPanel.add(labelsPanel, BorderLayout.WEST);
    mainPanel.add(fieldsPanel, BorderLayout.CENTER);
    mainPanel.add(submitButton, BorderLayout.EAST);

    setLayout(new BorderLayout());
    add(mainPanel, BorderLayout.NORTH);
    add(new JScrollPane(clientConsole), BorderLayout.CENTER);

    submitButton.addActionListener(new ButtonListener());



    setTitle("Exercise_1Client");
    setSize(400, 400);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setVisible(true); 

    try {
      Socket connectToServer = new Socket("localhost", 8000);
      inputFromServer = new DataInputStream(connectToServer.getInputStream());
      outputToServer =new DataOutputStream(connectToServer.getOutputStream());
    }
    catch (IOException ex) {
      clientConsole.append(ex.toString() + '\n');
    }
  }
private class ButtonListener implements ActionListener {
  public void actionPerformed(ActionEvent e) {
      try {
        double annualInterestRate = Double.parseDouble(annualRateField.getText().trim());
        int numOfYears = Integer.parseInt(numYearsField.getText());
        double loanAmount =Double.parseDouble(loanAmountField.getText().trim());
        outputToServer.writeDouble(annualInterestRate);
        outputToServer.writeInt(numOfYears);
        outputToServer.writeDouble(loanAmount);
        outputToServer.flush();
        
        double monthlyPayment = inputFromServer.readDouble();
        double totalPayment = inputFromServer.readDouble();

          clientConsole.append("Annual Interest Rate: " + annualInterestRate +
            " Number of Years: " + numOfYears + " Loan Amount: " +
            loanAmount + "\n");
          clientConsole.append(" monthlyPayment: " + monthlyPayment + " " +
            " totalPayment: " + totalPayment + '\n');
      }
      catch (IOException ex) {
        System.out.println("Error Occured!");
      }
    }
  }
}