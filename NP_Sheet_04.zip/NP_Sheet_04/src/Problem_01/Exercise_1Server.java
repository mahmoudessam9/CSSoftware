package Problem_01;

import java.io.*;
import java.net.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;

public class Exercise_1Server extends JFrame {

    private JTextArea serverConsole = new JTextArea();

    public static void main(String[] args) {
        new Exercise_1Server();
    }

    public Exercise_1Server() {

        setLayout(new BorderLayout());
        add(new JScrollPane(serverConsole), BorderLayout.CENTER);

        serverConsole.setWrapStyleWord(true);
        serverConsole.setLineWrap(true);

        setTitle("Exercise_1Server");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        try {
            ServerSocket serverSocket = new ServerSocket(8000);
            serverConsole.append("Exercise_1Server started at " + new Date() + '\n');

            int clientNo = 1;

            while (true) {
                Socket connectToClient = serverSocket.accept();
                InetAddress clientInetAddress = connectToClient.getInetAddress();
                serverConsole.append("Starting thread for client " + clientNo + " at " + new Date() + "\n");
                serverConsole.append("Client " + clientNo + "'s host name is " + clientInetAddress.getHostName() + "\n");
                serverConsole.append("Client " + clientNo + "'s IP Address is " + clientInetAddress.getHostAddress() + "\n");
                HandleAClient thread = new HandleAClient(connectToClient);
                thread.start();
                clientNo++;
            }
        } catch (IOException ex) {
            System.out.println("Error Ocurred!");
        }
    }

    class HandleAClient extends Thread {

        private Socket connectToClient;

        public HandleAClient(Socket socket) {
            connectToClient = socket;
        }

        public void run() {
            try {
                DataInputStream inputFromClient = new DataInputStream(connectToClient.getInputStream());
                DataOutputStream outputToClient = new DataOutputStream(connectToClient.getOutputStream());

                while (true) {
                    double annualInterestRate = inputFromClient.readDouble();

                    int numOfYears = inputFromClient.readInt();

                    double loanAmount = inputFromClient.readDouble();

                    Loan loan = new Loan(annualInterestRate, numOfYears, loanAmount);
                    double monthlyPayment = loan.getMonthlyPayment();
                    double totalPayment = loan.getMonthlyPayment();

                    outputToClient.writeDouble(monthlyPayment);
                    outputToClient.writeDouble(totalPayment);

                    serverConsole.append("Annual Interest Rate: " + annualInterestRate +"\n"); 
                    serverConsole.append("Number of Years: " + numOfYears + "\n");
                    serverConsole.append("Loan Amount: "+ loanAmount + "\n");
                    serverConsole.append(" monthlyPayment: " + monthlyPayment + "\n");
                    serverConsole.append(" totalPayment: " + totalPayment + "\n");
                }
            } catch (IOException e) {
                System.out.println("Error Ocurred!");
            }
        }
    }
}
